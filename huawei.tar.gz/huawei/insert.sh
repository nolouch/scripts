#!/bin/bash
if  [ $# != 3 ];  then
    echo "Usage: $0 port start end"
    exit 1
fi

port=$1
startT=$2
endT=$3

inputfile="test.txt"

cat $inputfile | for ((i = ${startT}; i <= ${endT}; i++))
do
echo "INSERT INTO t(a, b, c) VALUES($i, $i, 'pingcap');"
done | mysql -h 127.0.0.1 -P ${port} -u root -D test;


