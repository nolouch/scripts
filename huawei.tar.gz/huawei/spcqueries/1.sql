select count(*) from t;
